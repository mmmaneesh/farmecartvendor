package com.darryncampbell.cordova.plugin.intent;

public class CordovaPluginIntentFileProvider extends androidx.core.content.FileProvider {
}
