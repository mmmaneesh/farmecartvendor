var globalConfigs = {
  headers: {},
  serializer: 'urlencoded',
  followRedirect: true,
  timeout: 60.0,
};

module.exports = globalConfigs;
