import { BgImgDirective } from './bg-img.directive';

describe('BgImgDirective', () => {
  it('should create an instance', () => {
    const directive = new BgImgDirective();
    expect(directive).toBeTruthy();
  });
});
